//Author: Ramine Tinati
//Purpose: Node server for the Panoptes Researcher Dashboard

var app = require('http').createServer(handler);
var io = require('socket.io')(app);
var fs = require('fs');
//var config = require('./config');
var dateFormat = require('dateformat');
var mongoose = require('mongoose');
var Pusher = require('pusher-client');


//-------------------
//This is the working port
//PLEASE NOTE: You must configure this in order for this to correctly run. 
//Please find the port associate with your group and configure
app.listen(3005);




//-----------------------------
//SECTION: Databases and models
//We need to connect ot each of the datasets that we're going to be using.
//if you have more, follow the same pattern to connect
//NOTE: If you are running this locally, then the address for these datasets needs to be:
//  mongodb://sotonwo.cloudapp.net/

//Panoptes DATA                    
var pm_con = mongoose.createConnection('mongodb://localhost:27017/exampleDb');  // mongodb://woUser:webobservatory@localhost/zoo_panoptes
var db_pm = pm_con;
db_pm.on('error', console.error.bind(console, 'connection error:'));
db_pm.once('open', function (callback) {
    console.log("connected to database zoo_panoptes");
});

// //INFO: Mongoose requires that for a database connection, we create a schema, 
// //INFO: this is then attached to a collection. 
// //INFO: Three Schemas (but could use one if you wanted)
var pmDoc = new mongoose.Schema({
  source: String,
  // status: String,
  id: String, user: {
  country_name: String,
  country_code: String,
  user_id: String,
  project_id: String,
  subjects: String,
  created_at: { type : Date, default: Date.now },
  timestamp: { type : Date },
  lat: String,
  lng: String,
  test: String
  }
  
});

var commentsSchema = new mongoose.Schema({
  source: String,
  id: String, user: {
  project_id: String,
  board_id: String,
  discussion_id: String,
  focus_id: String,
  focus_type: String,
  user_id: String,
  section: String,
  body: String,
  timestamp: { type : Date },
  country_name: String,
  country_code: String,
  city_name: String,
  latitude: String,
  longitude: String
  }
  
});


// //INFO: These are the collections and models linked together
 var pm_Model = pm_con.model('classifications', pmDoc); // database collection for classifications stream 


 var pm_Model_Talk = pm_con.model('talk', commentsSchema); // database collection for talk stream

// // var air_pollution_Model = air_pollution_con.model('tweets_20151100', twitterDoc_pol); 
// // var shenzhen_Model = shenzhen_con.model('tweets_20151100', twitterDoc); 




//----------------------------
//SECTION: Pusher Work
//INFO: Connec using the pusher-client object, then bind to a channel and emit the stream
var socket = new Pusher('79e8e05ea522377ba6db',{
  encrypted: true
});
var channel = socket.subscribe('panoptes');

//console.log("trying to get data from pusher...")
channel.bind('classification',
  function(data) {

  //console.log(data)

    constructAndEmitLiveStream(data);

  }
);


var channelTwo = socket.subscribe('talk');

channelTwo.bind('comment',
  function(data) {

   // console.log(data)

    constructTalkAndEmitLiveStream(data);

  }
);




// { classification_id: '10054109',
//   project_id: '593',
//   workflow_id: '338',
//   user_id: '1447883',
//   geo:
//    { country_name: 'Greece',
//      country_code: 'GR',
//      city_name: 'Athens',
//      coordinates: [ 23.7333, 37.9833 ],
//      latitude: 37.9833,
//      longitude: 23.7333 } }



// TEST DATABASE QUERY //

// console.log("database dump: " + pm_Model.find()); // end Team.find

/*

var query = pm_Model.find({}).select('country_name');

query.exec(function (err, docs) {
       
    console.log(err);  //returns Null
    console.log("database dump: " + docs);  //returns Null.
       
    })
    
    */


// {"created_at": 1, "_id": 0} // words in find query shows created_at fields and removes the _id field from the output
// {"created_at" : { $gte : new Date(new Date().getTime()-60*5*1000).toISOString() }}

// {"status": 1}
// $gte : new Date(new Date().setDate(new Date().getMinutes()-10)) }}
var currentTime = new Date();

// {'created_at': {'$gt': new Date()}}
// {"created_at" : { $gte : new Date() }}

var start = new Date();
// start.setHours(0,0,0,0);

Array.prototype.contains = function(v) {
    for(var i = 0; i < this.length; i++) {
        if(this[i] === v) return true;
    }
    return false;
};

Array.prototype.unique = function() {
    var arr = [];
    for(var i = 0; i < this.length; i++) {
        if(!arr.contains(this[i])) {
            arr.push(this[i]);
        }
    }
    return arr; 
}

var recentUsers = [];
var userData = [];
var latitudeArray = [];
var longitudeArray = [];

  io.on('connection', function(socket){

pm_Model.find( {"user.timestamp" : { $gte : new Date()-10*60000 }} , {"user.user_id": 1, "user.timestamp": 1, "_id": 0} , function(err, docs){ // always put find query for time in the first {} not the second
    console.log(err);  //returns Null
    // recentUsers[0] =100;
       
  // console.log("docs: "+docs);
   
        
        
    for(var i=0; i<docs.length; i++) {
    
   // console.log("i: "+i);
   // recentUsers[i]["user_id"] = docs[i].user.user_id;
  //  recentUsers[i]["timestamp"] = docs[i].user.timestamp;
    
  //  console.log("recentUsers[i][user_id]: " + recentUsers[i]["user_id"]);
  //  console.log("recentUsers[i][timestamp]: " + recentUsers[i]["timestamp"]);
    
  //  console.log("recentUsers[i][user_id]: " + docs[i]["user_id"]);
  // console.log("recentUsers[i][timestamp]: " + docs[i]["timestamp"]);
    
    recentUsers.push(docs[i].user.user_id);
    
    }
    
   // console.log("users in the last 10 minutes: " + recentUsers);
   // console.log("original array length: "+recentUsers.length);
   
   // user id number 1806? seems strange investigate if you have time //
   
    console.log("unique array length: "+recentUsers.unique().filter(Boolean).length);
    console.log("unique users in the last 10 minutes: " + recentUsers.unique().filter(Boolean));
    
    recentUsers = recentUsers.unique().filter(Boolean);
    
    var count = 0;
    
     for(j=0; j<recentUsers.length; j++) {
        
    // console.log("j: "+j);
        
     pm_Model.find( {"user.timestamp" : { $gte : new Date()-10*60000 },"user.user_id" : recentUsers[j] } , {"user.user_id": 1,"user.lat": 1, "user.lng": 1, "user.timestamp": 1, "user.country_name": 1, "user.project_id": 1, "user.subjects": 1, "_id": 0} , function(err, userInfo){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null
    count++;
    
    userData.push(userInfo);
    
    
     
    
    console.log("userInfo user: "+userInfo[0].user.user_id);
     
  //   latitudeArray.push(lat[0].user.lat);
  //   longitudeArray.push(lat[0].user.lng);
  
  var recentUsersLength = recentUsers.length;
  
//  console.log("ç - 1: " + recentUsersLength);
//  console.log("count: "+count);
  
  if(count == recentUsers.length)
  {
   console.log("all unique users have been queried");
   
   
  
        
        
      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
     //  console.log("userData full array log to emit: " + userData[1][0]);
        
  io.emit("userData", userData);
  console.log('a user connected');
  
  userData = [];
  recentUsers = [];
  j = 0;
  i = 0;
  count = 0;
  

   
   
  }      
    }).limit(1) //.sort( { "user.timestamp": -1 } ); // end find  
          
          
     } // end for
     
    
     
    
    
});


          // COMMENTS QUERY //


          
           pm_Model_Talk.find( {"user.timestamp" : { $gte : new Date()-10*60000 } } , {"user.user_id": 1,"user.body": 1, "user.focus_id": 1, "user.timestamp": 1, "user.focus_type": 1, "user.project_id": 1, "user.subjects": 1, "_id": 0} , function(err, commentData){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null

 
    
   // console.log("commentData: "+commentData[0].user.user_id);


   console.log("comments in the last 10 minutes have been queried");

      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
    //   console.log("userData full array log to emit: " + userData[1][0]);
        
  io.emit("comments", commentData);
  console.log('a user connected');
  
  userData1 = [];
     
    });
          
           // COMMENTS QUERY END //


}); // end socket on connect

/*
 // WORD CLOUD QUERY //

        var wordBlob = "";
        var jsonWords;
        var wordArray = [];
          
           pm_Model_Talk.find( {} , {"user.body": 1, "_id": 0} , function(err, commentData){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null

 
    
    console.log("word commentData: "+commentData);
    
    for(k=0; k<commentData.length; k++)
      {
        wordBlob = wordBlob.concat(" " +commentData[k].user.body);
      }

console.log("wordBlob: " + wordBlob);

var wordCounts = { };
var newString = wordBlob.replace(/\./g, '');
var words = wordBlob.split(" ");


function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;        
}

for(var i = 0; i < 100; i++)
{
  
}

    // console.log( "newString: " + newString );
    
    words = words.filter(function( element ) {
   return element !== "undefined";
});
    
    jsonWords = JSON.stringify(words);
   // console.log( "words 1986: " + jsonWords );
   // console.log("words: " + words);
    
  // console.log("word blob complete");

      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
    //   console.log("userData full array log to emit: " + userData[1][0]);
        
 // io.emit("comments", commentData);
 // console.log('a user connected');
  
 // userData1 = [];
     
    });
          
           // WORD CLOUD QUERY END //
*/
 
 /*
  *pm_Model.find( {"timestamp" : { $gte : new Date()-10*60000 }} , {"user_id": 1, "_id": 0} , function(err, docs){ // always put find query for time in the first {} not the second
    console.log(err);  //returns Null
    // recentUsers[0] =100;
    for(var i=0; i<docs.length; i++) {
    
    console.log("i: "+i);  
    recentUsers.push(docs[i].user_id);
    
    }
    console.log("users in the last 10 minutes: " + recentUsers);
    console.log("original array length: "+recentUsers.length);
    console.log("unique array length: "+recentUsers.unique().length);
    console.log("unique users in the last 10 minutes: " + recentUsers.unique());
});

*/
 

/*
pm_Model.find({"created_at":{$gt:new Date(Date.now() - 24*60*60 * 1000)}}, function(err, docs){
    console.log(err);  //returns Null
    console.log("database dump from the last 24 hours: " + docs);  //returns Null.
});
*/

/*
pm_Model.find({
    created_at : { $gte : new Date(Date.now() - 1000 * 60 * 30) } },
  function(err, docs){
     console.log(err); //null
console.log(docs); //empty array []
  });
  */


function constructAndEmitLiveStream(data){

  //here we need to construct the object to confirm to what we were used to.

  var toSend = {};

  try{

    toSend["id"] = data.classification_id;
    toSend["country_name"] = data.geo.country_name;
    toSend["country_code"] = data.geo.country_code;
    toSend["user_id"] = data.user_id
    toSend["project_id"] = data.project_id
    toSend["subjects"] = data.classification_id
    toSend["created_at"] = new Date().toISOString()
    toSend["lat"] = data.geo.coordinates[0]
    toSend["lng"] = data.geo.coordinates[1]
 
    /*
    console.log("//////// LIVE STREAM \\\\\\\\");
    console.log(data);
    console.log("//////// LIVE STREAM ENDED \\\\\\\\"); // was "data" TRAVIS CHANGED
    */

   // io.emit("panoptes_classifications", toSend)

    //also need to send this data to the database.
    try{
      saveData(toSend)
     // console.log("saving data")
    }catch(e1){
        //console.log(e1)
    }

  }catch(e){

      //console.log(e)
	}	

}

function constructTalkAndEmitLiveStream(data){

  //here we need to construct the object to confirm to what we were used to.

  var toSend = {};

  try{

    toSend["id"] = data.project_id;
    toSend["board_id"] = data.board_id;
    toSend["discussion_id"] = data.discussion_id;
    toSend["user_id"] = data.user_id;
    toSend["project_id"] = data.project_id;
    toSend["section"] = data.section;
    toSend["body"] = data.body;
    toSend["focus_id"] = data.focus_id;
    toSend["focus_type"] = data.focus_type;
 //   toSend["created_at"] = new Date();
    toSend["country_name"] = data.geo.country_name;
    toSend["country_code"] = data.geo.country_code;
    toSend["city_name"] = data.geo.city_name;
    toSend["latitiude"] = data.geo.latitude; // added actual coordinates
    toSend["longitiude"] = data.geo.longitude; // added actual coordinates

    
   // console.log("//////// TALK STREAM \\\\\\\\");
   // console.log(data);
   // console.log("//////// TALK STREAM ENDED \\\\\\\\");
    

   // io.emit("panoptes_talk", toSend) // TRAVIS COMMENTED OUT

    //also need to send this data to the database.
    try{
      saveDataTalk(toSend)
      //console.log("saving data")
    }catch(e1){
        //console.log(e1)
    }

  }catch(e){

      //console.log(e)

  }

}






function saveData(obj){

    try{
        
        //console.log("Data: "+obj);

        var doc = new pm_Model({
            source: "panoptes_zooniverse",
            id: obj.id, user: {
            country_name: obj.country_name,
            country_code: obj.country_code,
            user_id: obj.user_id,
            project_id: obj.project_id,
            subjects: obj.subjects,
            timestamp: new Date(),
            lat: obj.lat,
            lng: obj.lng,
            test: "new schema" }
            
        });

        doc.save(function(err, doc) {
        if (err) return console.error(err);
        //console.dir(thor);
        });
            
            
        //console.log("Added New Items: "+data);
        //emit to real-time
      return true;
        }catch(e){
          console.log(e)
        }

}


function saveDataTalk(obj){

    try{

        //console.log("Data: "+obj);

        var doc = new pm_Model_Talk({
            source: "panoptes_zooniverse",
            id: obj.id, user: {
            project_id: obj.project_id,
            board_id: obj.board_id,
            discussion_id: obj.discussion_id,
            focus_id: obj.focus_id,
            focus_type: obj.focus_type,
            user_id: obj.user_id,
            section: obj.section,
            body: obj.body,
            timestamp: new Date(),
            country_name: obj.country_name,
            country_code: obj.country_code,
            city_name: obj.city_name,
            latitude: obj.latitude,
            longitude: obj.longitude }
        });

        doc.save(function(err, doc) {
        if (err) return console.error(err);
        //console.dir(thor);
        });


        //console.log("Added New Items: "+data);
        //emit to real-time
      return true;
        }catch(e){
          console.log(e)
        }

}





//----------------------------
//SECTION: SOCKET IO work

//INFO: When a connection is established with a client, the 'connection' port recieves a handshake
io.on('connection', function (socket) {

     //we want to automatically load the data to the client
     socket.on('load_data', function (data) {
        console.log("Loading Map Data");
        //console.log("emitting filter:", filter); 
        loadHistoricClassificationData(socket);  
    });

    //  //we will then proceed to load the pollution data
    //  socket.on('load_pollution_data', function (data) {
    //     console.log("Socket load_pollution_data called");
    //     //console.log("emitting filter:", filter); 
    //     loadPollutionTweets(socket);      
    // });
});


//----------------------------
//SECTION: Functions 

//INFO: This function retrieves ALL the pollution data in the collection and streams it to the client
function loadHistoricClassificationData(socket){
    console.log("Loading Historic Classification Data Timeseries");

    var toSend = [];

    var stream = pm_Model.find().stream();

    stream.on('data', function (doc) {
       var status = JSON.parse(doc.status);
        //console.log(status.created_at);  
        toSend.push(status.created_at);
        //socket.emit("historic_data", toSend);
        
    console.log("//////// LIVE STREAM \\\\\\\\");
    console.log(toSend);
    console.log("//////// LIVE STREAM ENDED \\\\\\\\"); // was "data" TRAVIS CHANGED
        
        
        //toSend = [];
      // do something with the mongoose document
    }).on('error', function (err) {
      // handle the error
    }).on('close', function () {        
      // the stream is closed

        //pre-process timestamps and then send them
        preprocesstimestamps(toSend,socket);
        
        
        
       // socket.emit("finished_sending_historic_classification_data", "");
        toSend = [];
        //loadPM25Data(socket)
    });

}


function preprocesstimestamps(toSend,socket){

 console.log("sending pre-processed timestamps as historic data")
  var timestamp_dist = {};
  var timeseries = [];

  for(var i=0; i<toSend.length; i++) {

    var data = toSend[i];
    var tstamp = Date.parse(data)
    var timestamp = dateFormat(tstamp, "yyyy-mm-dd hh:00:00");

    if(timestamp in timestamp_dist){
        var cnt = timestamp_dist[timestamp];
        timestamp_dist[timestamp] =cnt + 1
    }else{
        timestamp_dist[timestamp] = 1
    }

  }
        socket.emit("historic_data", timestamp_dist);


}



//########################
//NOTE: General patterns for retrieving data from the db and sending data to the client
// 1. Client requests data using a socket pulse
// 2. Server queries database using stream, sends data back to client via socket
// 3. When all data is finished being sent, server notifies client with new socket pulse
// 4. Server the proceeds to the next dataset.
//NOTE: Currently this happens sequentially, but this is not necessary...!
//#######################







//INFO: Misc functions whihc we use for the HTTP server.
function showErr (e) {
    console.error(e, e.stack);
}

function handler (req, res) {
    res.writeHead(1000); // was 200 TRAVIS CHANGED
    res.end("");
}

