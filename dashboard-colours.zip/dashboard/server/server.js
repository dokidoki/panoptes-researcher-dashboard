//Author: Ramine Tinati
//Purpose: Node server for the Panoptes Researcher Dashboard

var app = require('http').createServer(handler);
var io = require('socket.io')(app);
var fs = require('fs');
//var config = require('./config');
var dateFormat = require('dateformat');
var mongoose = require('mongoose');
var Pusher = require('pusher-client');


//-------------------
//This is the working port
//PLEASE NOTE: You must configure this in order for this to correctly run. 
//Please find the port associate with your group and configure
app.listen(3005);




//-----------------------------
//SECTION: Databases and models
//We need to connect ot each of the datasets that we're going to be using.
//if you have more, follow the same pattern to connect
//NOTE: If you are running this locally, then the address for these datasets needs to be:
//  mongodb://sotonwo.cloudapp.net/

//Panoptes DATA                    
var pm_con = mongoose.createConnection('mongodb://localhost:27017/exampleDb');  // mongodb://woUser:webobservatory@localhost/zoo_panoptes
var db_pm = pm_con;
db_pm.on('error', console.error.bind(console, 'connection error:'));
db_pm.once('open', function (callback) {
    console.log("connected to database zoo_panoptes");
});




// //INFO: Mongoose requires that for a database connection, we create a schema, 
// //INFO: this is then attached to a collection. 
// //INFO: Three Schemas (but could use one if you wanted)
var pmDoc = new mongoose.Schema({
  source: String,
  // status: String,
  id: String,
  country_name: String,
  country_code: String,
  user_id: String,
  project_id: String,
  subjects: String,
  created_at: { type : Date, default: Date.now },
  timestamp: { type : Date },
  lat: String,
  lng: String,
  test: String 
  
});

var commentsSchema = new mongoose.Schema({
  source: String,
  id: String,
  project_id: String,
  board_id: String,
  discussion_id: String,
  focus_id: String,
  focus_type: String,
  user_id: String,
  section: String,
  body: String,
  timestamp: { type : Date },
  country_name: String,
  country_code: String,
  city_name: String,
  latitude: String,
  longitude: String
  
});


// //INFO: These are the collections and models linked together
 var pm_Model = pm_con.model('classifications', pmDoc); // database collection for classifications stream 


 var pm_Model_Talk = pm_con.model('talk', commentsSchema); // database collection for talk stream

// // var air_pollution_Model = air_pollution_con.model('tweets_20151100', twitterDoc_pol); 
// // var shenzhen_Model = shenzhen_con.model('tweets_20151100', twitterDoc); 

//----------------------------
//SECTION: Pusher Work
//INFO: Connec using the pusher-client object, then bind to a channel and emit the stream
var socket = new Pusher('79e8e05ea522377ba6db',{
  encrypted: true
});
var channel = socket.subscribe('panoptes');

//console.log("trying to get data from pusher...")
channel.bind('classification',
  function(data) {

  //console.log(data)

    constructAndEmitLiveStream(data);

  }
);


var channelTwo = socket.subscribe('talk');

channelTwo.bind('comment',
  function(data) {

   // console.log(data)

    constructTalkAndEmitLiveStream(data);

  }
);




// { classification_id: '10054109',
//   project_id: '593',
//   workflow_id: '338',
//   user_id: '1447883',
//   geo:
//    { country_name: 'Greece',
//      country_code: 'GR',
//      city_name: 'Athens',
//      coordinates: [ 23.7333, 37.9833 ],
//      latitude: 37.9833,
//      longitude: 23.7333 } }



// TEST DATABASE QUERY //

// console.log("database dump: " + pm_Model.find()); // end Team.find

/*

var query = pm_Model.find({}).select('country_name');

query.exec(function (err, docs) {
       
    console.log(err);  //returns Null
    console.log("database dump: " + docs);  //returns Null.
       
    })
    
    */


// {"created_at": 1, "_id": 0} // words in find query shows created_at fields and removes the _id field from the output
// {"created_at" : { $gte : new Date(new Date().getTime()-60*5*1000).toISOString() }}

// {"status": 1}
// $gte : new Date(new Date().setDate(new Date().getMinutes()-10)) }}
var currentTime = new Date();

// {'created_at': {'$gt': new Date()}}
// {"created_at" : { $gte : new Date() }}

var start = new Date();
// start.setHours(0,0,0,0);

Array.prototype.contains = function(v) {
    for(var i = 0; i < this.length; i++) {
        if(this[i] === v) return true;
    }
    return false;
};

Array.prototype.unique = function() {
    var arr = [];
    for(var i = 0; i < this.length; i++) {
        if(!arr.contains(this[i])) {
            arr.push(this[i]);
        }
    }
    return arr; 
}

var recentUsers = [];
var userData = [];
var latitudeArray = [];
var longitudeArray = [];

  io.on('connection', function(socket){
    
     // SPECIFIC CLIENT CONNECT TEST //
 
socket.on('trendingWords', function (message) {
        console.log("the client trending words has connected");
        
        // WORD CLOUD QUERY //

        var wordBlob = "";
        var jsonWords;
        var wordArray = [];
          
           pm_Model_Talk.find( {} , {"body": 1, "_id": 0} , function(err, commentData){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null

 
    
 console.log("word commentData: "+commentData);
    
    for(k=0; k<commentData.length; k++)
      {
        wordBlob = wordBlob.concat(" " +commentData[k].body);
      }

// console.log("wordBlob: " + wordBlob);

var wordCounts = { };
// var newString =  wordBlob.replace(/\./g, '')//  wordBlob.replace(/\./g, '');

wordBlob = wordBlob.replace(/\./g, ""); // remove full stop(s)

wordBlob = wordBlob.replace(/\,/g, ""); // remove comma(s)

wordBlob = wordBlob.replace(/\'/g, ""); // remove comma(s)



/*

1  the
2  be
3  to
4  of
5  and
6  a
7  in
8  that
9  have
10  I
11  it
12	for
13	not
14	on
15	with
16	he
17	as
18	you
19	do
20	at
21	this
22	but
23	his
24	by
25	from
26	they
27	we
28	say
29	her
30	she
31	or
32	an
33	will
34	my
35	one
36	all
37	would
38	there
39	their
40	what
41	so
42	up
43	out
44	if
45	about
46	who
47	get
48	which
49	go
50	me
51	when
52	make
53	can
54	like
55	time
56	no
57	just
58	him
59	know
60	take
61	people
62	into
63	year
64	your
65	good
66	some
67	could
68	them
69	see
70	other
71	than
72	then
73	now
74	look
75	only
76	come
77	its
78	over
79	think
80	also
81	back
82	after
83	use
84	two
85	how
86	our
87	work
88	first
89	well
90	way
91	even
92	new
93	want
94	because
95	any
96	these
97	give
98	day
99	most
100	us
*/

filterWordsArray = ["the","be","to","of","and","a","in","that","have","I","it","for","not","on","with","he","as","you","do","at","this","but","his","by","from","they","we","say","her","she","or","an","will","my","one","all",
                    "would","there","their","what","so","up","out","if","about","who","get","which","go","me","when","make","can","like","time","no","just","him","know","take","people","into","year","your","good","some","could",
                    "them","see","other","than","then","now","look","only","come","its","over","think","also","back","after","use","two","how","our","work","first","well","way","even","new","want","because","any","these","give",
                    "day","most","us","is","a","s","are","was","very","Im","too"]; // added "is", "a" and "s" as they were also very commonon but lacked meaning

                    /*
                    
 for(var word=0; word<filterWordsArray.length; word++) {
    
var regExp = new RegExp(filterWordsArray[word],'/\w+/g');

var regExp1 = new RegExp( " " + filterWordsArray[word] ,'gi');
var regExp2 = new RegExp( filterWordsArray[word] ,'gi');

wordBlob = wordBlob.replace(regExp, ""); // remove undefined "/\" +  + "/g"

 }
 
 */
                    
                    wordBlob = wordBlob.replace(/\""/g, ""); // remove undefined ""

                    wordBlob = wordBlob.replace(/\undefined/g, ""); // remove undefined
                    
                    var individualWordsArray = [];
                    
                 individualWordsArray =  wordBlob.match(/\w+/gi);
                 
               //  console.log("individualWordsArray before: " + individualWordsArray);
                 
                 for(var k=0; k<individualWordsArray.length; k++) {
                    
                    for(var filter=0; filter<filterWordsArray.length; filter++) {
                        
                        // console.log("individualWordsArray[k]: " + individualWordsArray[k]);
                       //  console.log("filterWordsArray[filter]: " + filterWordsArray[filter]);
                        
                        if(individualWordsArray[k].toLowerCase() == filterWordsArray[filter].toLowerCase()) // normalise for captital letters
                        {
                            
                           //  console.log("word is the same!: " + individualWordsArray[k]);
                        // individualWordsArray.splice(k, 1); // remove filtered word from array
                         
                         individualWordsArray[k] = "";
                         
                         break;
                         
                        } // end if
                        
                    } // end filter for
                    
                 } // end word for
                 
                 
                 
                 
                              //  console.log("individualWordsArray after: " + individualWordsArray);
                 
                 
                 
                 
                 wordBlob = ""; // clear wordBlob
                 
                  for(var k=0; k<individualWordsArray.length; k++) {
                 
                 wordBlob = wordBlob.concat(" " +individualWordsArray[k]);
                 
                  }
                 
              
                // console.log("individualWordsArray after: " + individualWordsArray);
 
 
 

                    
//wordBlob.split(".").join(""); // remove commas
/* // potentially filter out the top 100 words to highlight more meaningful words/phrases also have a separate frequency list for hash tags


wordBlob = wordBlob.replace(/(?:\r\n|\r|\n)/g, " "); // remove line breaks



   /* Below is a regular expression that finds alphanumeric characters
       Next is a string that could easily be replaced with a reference to a form control
       Lastly, we have an array that will hold any words matching our pattern */
    var pattern = /\w+/g,
        string = "I I am am am yes yes.",
        matchedWords = wordBlob.match( pattern );

    /* The Array.prototype.reduce method assists us in producing a single value from an
       array. In this case, we're going to use it to output an object with results. */
    var counts = matchedWords.reduce(function ( stats, word, url ) {

        /* `stats` is the object that we'll be building up over time.
           `word` is each individual entry in the `matchedWords` array */
        if ( stats.hasOwnProperty( word ) ) {
            /* `stats` already has an entry for the current `word`.
               As a result, let's increment the count for that `word`. */
            stats[ word ] = stats[ word ] + 1;
        } else {
            /* `stats` does not yet have an entry for the current `word`.
               As a result, let's add a new entry, and set count to 1. */
            stats[ word ] = 1;
        }

        /* Because we are building up `stats` over numerous iterations,
           we need to return it for the next pass to modify it. */
        return stats;

    }, {} );

    // counts.sort();
    
    /* Now that `counts` has our object, we can log it. */
    
var sortable = [];
for (var word in counts)
    sortable.push([word, counts[word], "#comment-url"])

sortable.sort(function(a, b) {
    return   b[1] - a[1]
})

 console.log( sortable );
 
  io.emit("popularWords", sortable); // send popular words object to client
  /*
  counts.sort(function(a, b) {
    return parseFloat(a.price) - parseFloat(b.price);
});

*/
        
    }); 

//wordBlob.split("\n").join("TRAVIS"); // remove commas

var words = wordBlob.split(" "); // split words into array at each space " " between words

/*
for(var i = 0; i < 100; i++)
{
  
}
*/
    // console.log( "newString: " + newString );
    
    words = words.filter(function( element ) {
   return element !== "undefined";
});
    
    words = words.filter(function( element ) {
   return element !== "";
});
    
   // jsonWords = JSON.stringify(words);
   // console.log( "words: " + words );
   
  
   
    
  // console.log("word blob complete");

      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
    //   console.log("userData full array log to emit: " + userData[1][0]);
        
 // io.emit("comments", commentData);
 // console.log('a user connected');
  
 // userData1 = [];
     
    });
          
           // WORD CLOUD QUERY END //
        
        
         
 

pm_Model.find( {"timestamp" : { $gte : new Date()-10*60000 }} , {"user_id": 1, "timestamp": 1, "_id": 0} , function(err, docs){ // always put find query for time in the first {} not the second
  //  console.log(err);  //returns Null
    // recentUsers[0] =100;
       
  // console.log("docs: "+docs);
   
        
        
    for(var i=0; i<docs.length; i++) {
    
   // console.log("i: "+i);
   // recentUsers[i]["user_id"] = docs[i].user.user_id;
  //  recentUsers[i]["timestamp"] = docs[i].user.timestamp;
    
  //  console.log("recentUsers[i][user_id]: " + recentUsers[i]["user_id"]);
  //  console.log("recentUsers[i][timestamp]: " + recentUsers[i]["timestamp"]);
    
  //  console.log("recentUsers[i][user_id]: " + docs[i]["user_id"]);
  // console.log("recentUsers[i][timestamp]: " + docs[i]["timestamp"]);
    
    recentUsers.push(docs[i].user_id);
    
    }
    
   // console.log("users in the last 10 minutes: " + recentUsers);
   // console.log("original array length: "+recentUsers.length);
   
   // user id number 1806? seems strange investigate if you have time //
   
  //  console.log("unique array length: "+recentUsers.unique().filter(Boolean).length);
 //   console.log("unique users in the last 10 minutes: " + recentUsers.unique().filter(Boolean));
    
    recentUsers = recentUsers.unique().filter(Boolean);
    
    var count = 0;
    
     for(j=0; j<recentUsers.length; j++) {
        
    // console.log("j: "+j);
        
     pm_Model.find( {"timestamp" : { $gte : new Date()-10*60000 },"user_id" : recentUsers[j] } , {"user_id": 1,"lat": 1, "lng": 1, "timestamp": 1, "country_name": 1, "project_id": 1, "subjects": 1, "_id": 0} , function(err, userInfo){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null
    count++;
    
    userData.push(userInfo);
    
    
     
    
  //  console.log("userInfo user: "+userInfo[0].user.user_id);
     
  //   latitudeArray.push(lat[0].user.lat);
  //   longitudeArray.push(lat[0].user.lng);
  
  var recentUsersLength = recentUsers.length;
  
//  console.log("ç - 1: " + recentUsersLength);
//  console.log("count: "+count);
  
  if(count == recentUsers.length)
  {
  // console.log("all unique users have been queried");
   
   
  
        
        
      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
     //  console.log("userData full array log to emit: " + userData[1][0]);
        
  io.emit("userData", userData);
//  console.log('a user connected');
  
  userData = [];
  recentUsers = [];
  j = 0;
  i = 0;
  count = 0;
  

   
   
  }      
    }).limit(1) //.sort( { "user.timestamp": -1 } ); // end find  
          
          
     } // end for
     
    
     
    
    
});


          // COMMENTS QUERY //


          
           pm_Model_Talk.find( {"timestamp" : { $gte : new Date()-10*60000 } } , {"user_id": 1,"body": 1, "focus_id": 1, "timestamp": 1, "focus_type": 1, "project_id": 1, "subjects": 1, "latitude": 1, "longitude": 1, "_id": 0} , function(err, commentData){ // always put find query for time in the first {} not the second
   // console.log(err);  //returns Null

 
    
   // console.log("commentData latitude: "+commentData[0].user.latitude);


//   console.log("comments in the last 10 minutes have been queried");

      //  console.log("userData to emit: "+userData);
        
       //  console.log("userInfo user to emit: "+userData[1][0].user.user_id);
      //  console.log("/////////////////////////////////////////////////");
    //   console.log("userData full array log to emit: " + userData[1][0]);
        
  io.emit("comments", commentData);
// console.log('a user connected');
  
  userData1 = [];
     
    });
          
           // COMMENTS QUERY END //


}); // end socket on connect

 
 /*
  *pm_Model.find( {"timestamp" : { $gte : new Date()-10*60000 }} , {"user_id": 1, "_id": 0} , function(err, docs){ // always put find query for time in the first {} not the second
    console.log(err);  //returns Null
    // recentUsers[0] =100;
    for(var i=0; i<docs.length; i++) {
    
    console.log("i: "+i);  
    recentUsers.push(docs[i].user_id);
    
    }
    console.log("users in the last 10 minutes: " + recentUsers);
    console.log("original array length: "+recentUsers.length);
    console.log("unique array length: "+recentUsers.unique().length);
    console.log("unique users in the last 10 minutes: " + recentUsers.unique());
});

*/
 

/*
pm_Model.find({"created_at":{$gt:new Date(Date.now() - 24*60*60 * 1000)}}, function(err, docs){
    console.log(err);  //returns Null
    console.log("database dump from the last 24 hours: " + docs);  //returns Null.
});
*/

/*
pm_Model.find({
    created_at : { $gte : new Date(Date.now() - 1000 * 60 * 30) } },
  function(err, docs){
     console.log(err); //null
console.log(docs); //empty array []
  });
  */


function constructAndEmitLiveStream(data){

  //here we need to construct the object to confirm to what we were used to.

  var toSend = {};

  try{

    toSend["id"] = data.classification_id;
    toSend["country_name"] = data.geo.country_name;
    toSend["country_code"] = data.geo.country_code;
    toSend["user_id"] = data.user_id
    toSend["project_id"] = data.project_id
    toSend["subjects"] = data.classification_id
    toSend["timestamp"] = new Date();
    toSend["lat"] = data.geo.coordinates[0]
    toSend["lng"] = data.geo.coordinates[1]
 
    /*
    console.log("//////// LIVE STREAM \\\\\\\\");
    console.log(data);
    console.log("//////// LIVE STREAM ENDED \\\\\\\\"); // was "data" TRAVIS CHANGED
    */

   io.emit("panoptes_classifications", toSend)

    //also need to send this data to the database.
    try{
      saveData(toSend)
     // console.log("saving data")
    }catch(e1){
        //console.log(e1)
    }

  }catch(e){

      //console.log(e)
	}	

}

function constructTalkAndEmitLiveStream(data){

  //here we need to construct the object to confirm to what we were used to.

  var toSend = {};

  try{

    toSend["id"] = data.project_id;
    toSend["board_id"] = data.board_id;
    toSend["discussion_id"] = data.discussion_id;
    toSend["user_id"] = data.user_id;
    toSend["project_id"] = data.project_id;
    toSend["section"] = data.section;
    toSend["body"] = data.body;
    toSend["focus_id"] = data.focus_id;
    toSend["focus_type"] = data.focus_type;
    toSend["timestamp"] = new Date();
    toSend["country_name"] = data.geo.country_name;
    toSend["country_code"] = data.geo.country_code;
    toSend["city_name"] = data.geo.city_name;
    toSend["latitude"] = data.geo.coordinates[0]; 
    toSend["longitude"] = data.geo.coordinates[1]; 

    
   // console.log("//////// TALK STREAM \\\\\\\\");
   // console.log(toSend);
   // console.log("//////// TALK STREAM ENDED \\\\\\\\");
    

   io.emit("panoptes_talk", toSend) // TRAVIS COMMENTED OUT

    //also need to send this data to the database.
    try{
      saveDataTalk(toSend)
      //console.log("saving data")
    }catch(e1){
        //console.log(e1)
    }

  }catch(e){

      //console.log(e)

  }

}






function saveData(obj){

    try{
        
        //console.log("Data: "+obj);

        var doc = new pm_Model({
            source: "panoptes_zooniverse",
            id: obj.id,
            country_name: obj.country_name,
            country_code: obj.country_code,
            user_id: obj.user_id,
            project_id: obj.project_id,
            subjects: obj.subjects,
            timestamp: new Date(),
            lat: obj.lat,
            lng: obj.lng,
            test: "new schema" 
            
        });

        doc.save(function(err, doc) {
        if (err) return console.error(err);
        //console.dir(thor);
        });
            
            
        //console.log("Added New Items: "+data);
        //emit to real-time
      return true;
        }catch(e){
          console.log(e)
        }

}


function saveDataTalk(obj){

    try{

        //console.log("Data: "+obj);

        var doc = new pm_Model_Talk({
            source: "panoptes_zooniverse",
            id: obj.id,
            project_id: obj.project_id,
            board_id: obj.board_id,
            discussion_id: obj.discussion_id,
            focus_id: obj.focus_id,
            focus_type: obj.focus_type,
            user_id: obj.user_id,
            section: obj.section,
            body: obj.body,
            timestamp: new Date(),
            country_name: obj.country_name,
            country_code: obj.country_code,
            city_name: obj.city_name,
            latitude: obj.latitude,
            longitude: obj.longitude 
        });

        doc.save(function(err, doc) {
        if (err) return console.error(err);
        //console.dir(thor);
        });


        //console.log("Added New Items: "+data);
        //emit to real-time
      return true;
        }catch(e){
          console.log(e)
        }

}





//----------------------------
//SECTION: SOCKET IO work

//INFO: When a connection is established with a client, the 'connection' port recieves a handshake
io.on('connection', function (socket) {

     //we want to automatically load the data to the client
     socket.on('load_data', function (data) {
        console.log("Loading Map Data");
        //console.log("emitting filter:", filter); 
        loadHistoricClassificationData(socket);  
    });

    //  //we will then proceed to load the pollution data
    //  socket.on('load_pollution_data', function (data) {
    //     console.log("Socket load_pollution_data called");
    //     //console.log("emitting filter:", filter); 
    //     loadPollutionTweets(socket);      
    // });
});


//----------------------------
//SECTION: Functions 

//INFO: This function retrieves ALL the pollution data in the collection and streams it to the client
function loadHistoricClassificationData(socket){
    console.log("Loading Historic Classification Data Timeseries");

    var toSend = [];

    var stream = pm_Model.find().stream();

    stream.on('data', function (doc) {
       var status = JSON.parse(doc.status);
        //console.log(status.created_at);  
        toSend.push(status.created_at);
        //socket.emit("historic_data", toSend);
        
    console.log("//////// LIVE STREAM \\\\\\\\");
    console.log(toSend);
    console.log("//////// LIVE STREAM ENDED \\\\\\\\"); // was "data" TRAVIS CHANGED
        
        
        //toSend = [];
      // do something with the mongoose document
    }).on('error', function (err) {
      // handle the error
    }).on('close', function () {        
      // the stream is closed

        //pre-process timestamps and then send them
        preprocesstimestamps(toSend,socket);
        
        
        
       // socket.emit("finished_sending_historic_classification_data", "");
        toSend = [];
        //loadPM25Data(socket)
    });

}


function preprocesstimestamps(toSend,socket){

 console.log("sending pre-processed timestamps as historic data")
  var timestamp_dist = {};
  var timeseries = [];

  for(var i=0; i<toSend.length; i++) {

    var data = toSend[i];
    var tstamp = Date.parse(data)
    var timestamp = dateFormat(tstamp, "yyyy-mm-dd hh:00:00");

    if(timestamp in timestamp_dist){
        var cnt = timestamp_dist[timestamp];
        timestamp_dist[timestamp] =cnt + 1
    }else{
        timestamp_dist[timestamp] = 1
    }

  }
        socket.emit("historic_data", timestamp_dist);


}



//########################
//NOTE: General patterns for retrieving data from the db and sending data to the client
// 1. Client requests data using a socket pulse
// 2. Server queries database using stream, sends data back to client via socket
// 3. When all data is finished being sent, server notifies client with new socket pulse
// 4. Server the proceeds to the next dataset.
//NOTE: Currently this happens sequentially, but this is not necessary...!
//#######################







//INFO: Misc functions whihc we use for the HTTP server.
function showErr (e) {
    console.error(e, e.stack);
}

function handler (req, res) {
    res.writeHead(1000); // was 200 TRAVIS CHANGED
    res.end("");
}

